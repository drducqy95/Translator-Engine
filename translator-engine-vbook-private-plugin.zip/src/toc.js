load("config.js");

function _novelByLink(link) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return null;
    for (var i = 0; i < catalog.novels.length; i++) {
        var novel = catalog.novels[i];
        if (samePath(novel.toc || "", link) || samePath(novel.readme || "", link)) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByLink(url);
    if (!novel) return Response.success([]);
    var toc = readJson(joinUrl(BASE_URL, novel.toc));
    if (!toc || !toc.chapters) return Response.success([]);
    var list = [];
    toc.chapters.forEach(function(ch) {
        var path = ch.path || ch.file || "";
        if (!path) return;
        if (path.indexOf('/') < 0) path = (novel.novel || toc.novel || "") + "/" + path;
        list.push({
            name: cleanName(ch.title || ch.file || path),
            url: "repo:" + path,
            host: BASE_URL
        });
    });
    return Response.success(list);
}
