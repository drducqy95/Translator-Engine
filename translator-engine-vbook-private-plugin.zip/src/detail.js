load("config.js");

function _novelByLink(link) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return null;
    for (var i = 0; i < catalog.novels.length; i++) {
        var novel = catalog.novels[i];
        if (samePath(novel.toc || "", link) || samePath(novel.readme || "", link)) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByLink(url);
    if (!novel) return null;
    var toc = readJson(joinUrl(BASE_URL, novel.toc)) || {};
    var readme = readText(joinUrl(BASE_URL, novel.readme));
    var chapters = toc.chapters || [];
    var readmeHtml = mdToHtml(readme);
    return Response.success({
        name: cleanName((readme.match(/^#\s*(.+)$/m) || [])[1] || toc.novel || novel.novel || novel.title || novel.name || ""),
        cover: "",
        host: BASE_URL,
        author: "",
        description: "Chapters: " + chapters.length,
        detail: readmeHtml,
        ongoing: false,
        genres: [],
        suggests: []
    });
}
