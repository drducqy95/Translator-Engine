var REPO_OWNER = "drducqy95";
var REPO_NAME = "Translator-Engine";
var REPO_BRANCH = "master";
var GITHUB_TOKEN = "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";
var API_BASE = "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME + "/contents";
var BASE_URL = API_BASE + "/Final_Output_ASCII";
var HOME_URL = API_BASE + "/Final_Output_ASCII/toc.json?ref=" + REPO_BRANCH;

function requestOptions(raw) {
    var headers = {
        "Accept": raw ? "application/vnd.github.raw+json" : "application/vnd.github+json",
        "User-Agent": "translator-engine-vbook"
    };
    if (GITHUB_TOKEN) headers["Authorization"] = "Bearer " + GITHUB_TOKEN;
    return { headers: headers };
}

function readText(url) {
    var res = fetch(url, requestOptions(true));
    if (!res || !res.ok) return "";
    if (typeof res.text === "function") return res.text() || "";
    if (typeof res.body === "string") return res.body;
    return "";
}

function readJson(url) {
    var text = readText(url);
    if (!text) {
        var meta = fetch(url, requestOptions(false));
        if (!meta || !meta.ok) return null;
        if (typeof meta.text === "function") text = meta.text() || "";
        else if (typeof meta.body === "string") text = meta.body;
    }
    if (!text) return null;
    try {
        return JSON.parse(text);
    } catch (e) {
        return null;
    }
}

function joinUrl(base, path) {
    if (!path) return base;
    if (/^https?:\/\//i.test(path)) return path;
    var url = base.replace(/\/$/, "") + "/" + path.replace(/^\//, "");
    if (url.indexOf("?ref=") < 0) url += "?ref=" + REPO_BRANCH;
    return url;
}

function samePath(a, b) {
    a = (a || "").toString();
    b = (b || "").toString();
    b = b.replace(/^repo:/, "");
    if (!a || !b) return false;
    if (a === b) return true;
    return a.replace(/^.*Final_Output_ASCII\//, "") === b.replace(/^.*Final_Output_ASCII\//, "");
}

function stripRef(url) {
    return (url || "").replace(/^repo:/, "").replace(/\?ref=[^&]+/g, "");
}

function cleanName(name) {
    return (name || "").toString().replace(/\s+/g, " ").trim();
}

function mdToText(md) {
    return (md || "")
        .replace(/```[\s\S]*?```/g, "")
        .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, "")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1")
        .replace(/^#{1,6}\s*/gm, "")
        .replace(/^[-*_]{3,}\s*$/gm, "\n")
        .replace(/^\s*>\s?/gm, "")
        .replace(/^\s*[-*+]\s+/gm, "• ")
        .replace(/\r/g, "")
        .replace(/[ \t]+\n/g, "\n")
        .replace(/\n{4,}/g, "\n\n\n")
        .trim();
}

function mdToHtml(md) {
    var text = (md || "").toString();
    text = text.replace(/\r/g, "");
    text = text.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');
    text = text.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
    text = text.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
    text = text.replace(/^\-\s+(.+)$/gm, '<li>$1</li>');
    text = text.replace(/\n\n+/g, '</p><p>');
    text = text.replace(/^(?!<h[1-3]>|<li>|<\/p>)(.+)$/gm, '<p>$1</p>');
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    text = text.replace(/<p><li>/g, '<ul><li>').replace(/<\/li><\/p>/g, '</li></ul>');
    return text;
}
