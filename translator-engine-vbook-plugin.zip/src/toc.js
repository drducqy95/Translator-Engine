load("config.js");

function _novelByToc(url) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return null;
    var target = (url || "");
    for (var i = 0; i < catalog.novels.length; i++) {
        var novel = catalog.novels[i];
        if ((novel.toc || "") === target || (novel.readme || "") === target) return novel;
        if (joinUrl(BASE_URL, novel.toc || "") === target || joinUrl(BASE_URL, novel.readme || "") === target) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByToc(url);
    if (!novel) return Response.success([]);
    var tocUrl = joinUrl(BASE_URL, novel.toc);
    var toc = readJson(tocUrl);
    if (!toc || !toc.chapters) return Response.success([]);

    var list = [];
    toc.chapters.forEach(function(ch) {
        var path = ch.path || ch.file || "";
        if (!path) return;
        if (path.indexOf('/') < 0) path = (novel.novel || toc.novel || "") + "/" + path;
        list.push({
            name: cleanName(ch.title || ch.file || path),
            url: path,
            host: BASE_URL
        });
    });
    return Response.success(list);
}
