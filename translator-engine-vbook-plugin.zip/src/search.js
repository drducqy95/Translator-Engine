load("config.js");

function execute(key, page) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return Response.success([]);
    var query = cleanName((key || "").toString()).toLowerCase();
    var list = [];
    catalog.novels.forEach(function(novel) {
        var title = cleanName(novel.novel || novel.title || novel.name || "");
        if (!query || query === "all" || title.toLowerCase().indexOf(query) >= 0) {
            list.push({
                name: title,
                link: novel.toc || novel.readme || "",
                cover: "",
                description: "Chapters: " + (novel.chapter_count || 0),
                host: BASE_URL
            });
        }
    });
    return Response.success(list, null);
}
