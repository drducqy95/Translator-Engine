load("config.js");

function execute(key, page) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return Response.success([]);

    var query = cleanName((key || "").toString()).toLowerCase();
    var list = [];

    catalog.novels.forEach(function(novel) {
        var title = cleanName(novel.novel || novel.title || novel.name || "");
        var readme = novel.readme || "";
        var toc = novel.toc || "";
        var needle = (title + " " + readme + " " + toc).toLowerCase();
        if (!query || query === "all" || needle.indexOf(query) >= 0) {
            list.push({
                name: title,
                link: toc,
                cover: "",
                description: "Chapters: " + (novel.chapter_count || 0),
                host: BASE_URL
            });
        }
    });

    return Response.success(list, null);
}
