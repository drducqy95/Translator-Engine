load("config.js");

function execute() {
    return Response.success([
        { title: "Repo truyện", input: "all", script: "search.js" },
    ]);
}
