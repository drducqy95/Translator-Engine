load("config.js");

function execute(url) {
    var text = readText(joinUrl(BASE_URL, url));
    if (!text) return null;
    return Response.success(mdToText(text));
}
