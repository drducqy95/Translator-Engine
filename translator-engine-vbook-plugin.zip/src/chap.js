load("config.js");

function execute(url) {
    var fullUrl = joinUrl(BASE_URL, url);
    var md = readText(fullUrl);
    if (!md) return null;
    return Response.success(mdToText(md));
}
