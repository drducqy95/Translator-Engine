load("config.js");

function _novelByLink(link) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return null;
    for (var i = 0; i < catalog.novels.length; i++) {
        var novel = catalog.novels[i];
        if ((novel.toc || "") === link || (novel.readme || "") === link) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByLink(url);
    if (!novel) return null;
    var toc = readJson(joinUrl(BASE_URL, novel.toc)) || {};
    var readme = readText(joinUrl(BASE_URL, novel.readme));
    var chapters = toc.chapters || [];
    return Response.success({
        name: cleanName(toc.novel || novel.novel || novel.title || novel.name || ""),
        cover: "",
        host: BASE_URL,
        author: "Translator Engine",
        description: "Chapters: " + chapters.length,
        detail: mdToText(readme),
        ongoing: false,
        genres: [],
        suggests: []
    });
}
