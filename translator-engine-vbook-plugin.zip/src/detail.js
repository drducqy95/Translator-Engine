load("config.js");

function _novelByToc(url) {
    var catalog = readJson(HOME_URL);
    if (!catalog || !catalog.novels) return null;
    var target = (url || "");
    for (var i = 0; i < catalog.novels.length; i++) {
        var novel = catalog.novels[i];
        if ((novel.toc || "") === target || (novel.readme || "") === target) return novel;
        if (joinUrl(BASE_URL, novel.toc || "") === target || joinUrl(BASE_URL, novel.readme || "") === target) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByToc(url);
    if (!novel) return null;

    var tocUrl = joinUrl(BASE_URL, novel.toc);
    var readmeUrl = joinUrl(BASE_URL, novel.readme);
    var toc = readJson(tocUrl) || {};
    var readme = readText(readmeUrl);
    var chapters = toc.chapters || [];
    var first = chapters.length ? chapters[0] : null;
    var last = chapters.length ? chapters[chapters.length - 1] : null;
    var desc = [
        "Chapters: " + (novel.chapter_count || chapters.length || 0),
        first ? ("First: " + cleanName(first.title || first.file || "")) : "",
        last ? ("Last: " + cleanName(last.title || last.file || "")) : ""
    ].filter(function(x) { return x; }).join("\n");

    return Response.success({
        name: cleanName(toc.novel || novel.novel || novel.title || novel.name || ""),
        cover: "",
        host: BASE_URL,
        author: "",
        description: desc,
        detail: mdToText(readme),
        ongoing: false,
        genres: [{ title: "GitHub Repo", input: novel.toc, script: "toc.js" }],
        suggests: []
    });
}
