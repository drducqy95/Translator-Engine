var BASE_URL = "https://raw.githubusercontent.com/drducqy95/Translator-Engine/master/Final_Output_ASCII";
var HOME_URL = BASE_URL + "/toc.json";
try {
    if (typeof CONFIG_URL !== "undefined" && CONFIG_URL) BASE_URL = CONFIG_URL;
} catch (e) {}

function joinUrl(base, path) {
    if (!path) return base;
    if (/^https?:\/\//i.test(path)) return path;
    if (path.charAt(0) === "/") return base.replace(/\/$/, "") + path;
    return base.replace(/\/$/, "") + "/" + path.replace(/^\//, "");
}

function readText(url) {
    var res = fetch(url);
    if (!res || !res.ok) return "";
    if (typeof res.text === "function") return res.text() || "";
    if (typeof res.body === "string") return res.body;
    return "";
}

function readJson(url) {
    var text = readText(url);
    if (!text) return null;
    try {
        return JSON.parse(text);
    } catch (e) {
        return null;
    }
}

function slugify(text) {
    text = (text || "").toString();
    return text
        .normalize ? text.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : text
        .replace(/đ/g, "d").replace(/Đ/g, "D")
        .replace(/[^A-Za-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
}

function cleanName(name) {
    return (name || "").toString().replace(/\s+/g, " ").trim();
}

function mdToText(md) {
    return (md || "")
        .replace(/```[\s\S]*?```/g, "")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1")
        .replace(/^#{1,6}\s*/gm, "")
        .replace(/\r/g, "")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
}
