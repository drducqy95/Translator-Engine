var REPO_OWNER = "drducqy95";
var REPO_NAME = "Translator-Engine";
var REPO_BRANCH = "master";
var GITHUB_TOKEN = "";
try {
    if (typeof CONFIG_URL !== "undefined" && CONFIG_URL) {
        if (/^https?:\/\//i.test(CONFIG_URL)) {
            REPO_BRANCH = CONFIG_URL;
        } else {
            GITHUB_TOKEN = CONFIG_URL;
        }
    }
} catch (e) {}

var API_BASE = "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME + "/contents";
var HOME_URL = API_BASE + "/Final_Output_ASCII/toc.json?ref=" + REPO_BRANCH;

function requestOptions() {
    var headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "translator-engine-vbook"
    };
    if (GITHUB_TOKEN) headers["Authorization"] = "Bearer " + GITHUB_TOKEN;
    return { headers: headers };
}

function readText(url) {
    var res = fetch(url, requestOptions());
    if (!res || !res.ok) return "";
    if (typeof res.text === "function") return res.text() || "";
    if (typeof res.body === "string") return res.body;
    return "";
}

function readJson(url) {
    var text = readText(url);
    if (!text) return null;
    try {
        return JSON.parse(text);
    } catch (e) {
        return null;
    }
}

function joinUrl(base, path) {
    if (!path) return base;
    if (/^https?:\/\//i.test(path)) return path;
    return base.replace(/\/$/, "") + "/" + path.replace(/^\//, "");
}

function cleanName(name) {
    return (name || "").toString().replace(/\s+/g, " ").trim();
}

function mdToText(md) {
    return (md || "")
        .replace(/```[\s\S]*?```/g, "")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1")
        .replace(/^#{1,6}\s*/gm, "")
        .replace(/\r/g, "")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
}
