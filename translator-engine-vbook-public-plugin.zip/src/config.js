var REPO_OWNER = "drducqy95";
var REPO_NAME = "Translator-Engine";
var REPO_BRANCH = "master";
var RAW_ROOT = "https://raw.githubusercontent.com/" + REPO_OWNER + "/" + REPO_NAME + "/" + REPO_BRANCH;
var BASE_URL = RAW_ROOT;
var HOME_URL = RAW_ROOT + "/Output/home.json";

function readText(url) {
    var res = fetch(url);
    if (!res || !res.ok) return "";
    if (typeof res.text === "function") return res.text() || "";
    if (typeof res.body === "string") return res.body;
    return "";
}

function readJson(url) {
    var text = readText(url);
    if (!text) return null;
    try { return JSON.parse(text); } catch (e) { return null; }
}

function joinUrl(base, path) {
    if (!path) return base;
    if (/^https?:\/\//i.test(path)) return path;
    return base.replace(/\/$/, "") + "/" + path.replace(/^\//, "");
}

function samePath(a, b) {
    a = (a || "").toString().replace(/^repo:/, "");
    b = (b || "").toString().replace(/^repo:/, "");
    return !!a && !!b && a === b;
}

function stripRepo(url) {
    return (url || "").toString().replace(/^repo:/, "").replace(/\?ref=[^&]+/g, "");
}

function cleanName(name) {
    return (name || "").toString().replace(/\s+/g, " ").trim();
}

function mdToText(md) {
    return (md || "")
        .replace(/```[\s\S]*?```/g, "")
        .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, "")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1")
        .replace(/^#{1,6}\s*/gm, "")
        .replace(/^[-*_]{3,}\s*$/gm, "\n")
        .replace(/^\s*>\s?/gm, "")
        .replace(/^\s*[-*+]\s+/gm, "• ")
        .replace(/\r/g, "")
        .replace(/[ \t]+\n/g, "\n")
        .replace(/\n{4,}/g, "\n\n\n")
        .trim();
}

function mdToHtml(md) {
    var text = (md || "").toString().replace(/\r/g, "");
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    text = text.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
    text = text.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
    text = text.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');
    text = text.replace(/^\-\s+(.+)$/gm, '<li>$1</li>');
    text = text.replace(/\n\n+/g, '</p><p>');
    text = text.replace(/^(?!<h[1-3]>|<li>|<\/p>|<ul>|<\/ul>)(.+)$/gm, '<p>$1</p>');
    text = text.replace(/<p><li>/g, '<ul><li>').replace(/<\/li><\/p>/g, '</li></ul>');
    return text;
}
