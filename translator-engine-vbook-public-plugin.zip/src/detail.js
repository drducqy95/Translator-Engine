load("config.js");

function _novelByLink(link) {
    var home = readJson(HOME_URL);
    if (!home || !home.novels) return null;
    link = stripRepo(link);
    for (var i = 0; i < home.novels.length; i++) {
        var novel = home.novels[i];
        if (samePath(novel.toc || "", link) || samePath(novel.readme || "", link)) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByLink(url);
    if (!novel) return null;
    var toc = readJson(joinUrl(BASE_URL, novel.toc)) || {};
    var readme = readText(joinUrl(BASE_URL, novel.readme));
    return Response.success({
        name: cleanName(novel.title || toc.novel_id || novel.branch || ""),
        cover: novel.cover ? joinUrl(BASE_URL, "Output/" + novel.branch + "/" + novel.cover) : "",
        host: BASE_URL,
        author: novel.author || (toc.metadata ? toc.metadata.author : "") || "",
        description: novel.description || novel.summary || "",
        detail: readme ? mdToHtml(readme) : (novel.summary || novel.description || ""),
        ongoing: !!novel.ongoing,
        genres: [],
        suggests: []
    });
}
