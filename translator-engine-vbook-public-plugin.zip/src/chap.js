load("config.js");

function execute(url) {
    var path = stripRepo(url);
    var text = readText(joinUrl(BASE_URL, path));
    if (!text) return null;
    return Response.success(mdToText(text));
}
