load("config.js");

function _novelByLink(link) {
    var home = readJson(HOME_URL);
    if (!home || !home.novels) return null;
    link = stripRepo(link);
    for (var i = 0; i < home.novels.length; i++) {
        var novel = home.novels[i];
        if (samePath(novel.toc || "", link)) return novel;
    }
    return null;
}

function execute(url) {
    var novel = _novelByLink(url);
    if (!novel) return Response.success([]);
    var toc = readJson(joinUrl(BASE_URL, novel.toc));
    if (!toc || !toc.chapters) return Response.success([]);
    var list = [];
    toc.chapters.forEach(function(ch) {
        if (ch.status && ch.status !== "done") return;
        var file = ch.translated_file || ch.file || "";
        if (!file) return;
        var path = "Output/" + novel.branch + "/Final_Translated/" + file;
        list.push({ name: cleanName(ch.title || file), url: "repo:" + path, host: BASE_URL });
    });
    return Response.success(list);
}
