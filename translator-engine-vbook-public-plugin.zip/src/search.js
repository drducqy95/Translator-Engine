load("config.js");

function execute(key, page) {
    var home = readJson(HOME_URL);
    if (!home || !home.novels) return Response.success([]);
    var query = cleanName((key || "").toString()).toLowerCase();
    var list = [];
    home.novels.forEach(function(novel) {
        var title = cleanName(novel.title || novel.branch || "");
        var hay = (title + " " + (novel.author || "") + " " + (novel.branch || "")).toLowerCase();
        if (!query || query === "all" || hay.indexOf(query) >= 0) {
            list.push({
                name: title,
                link: "repo:" + (novel.toc || ""),
                cover: novel.cover ? joinUrl(BASE_URL, "Output/" + novel.branch + "/" + novel.cover) : "",
                description: (novel.author || "") + "\n" + (novel.description || novel.summary || ""),
                host: BASE_URL
            });
        }
    });
    return Response.success(list, null);
}
